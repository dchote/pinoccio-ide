/* Generated automatically. */
static const char configuration_arguments[] = "../configure --disable-shared --enable-static --prefix=/Users/daniel/Projects/Pinoccio/pinoccio-firmware/build --target=avr --enable-languages=c,c++ --disable-libssp --disable-nls --with-dwarf2 --with-gmp=/Users/daniel/Projects/Pinoccio/pinoccio-firmware/working/gmp-5.0.5 --with-mpfr=/Users/daniel/Projects/Pinoccio/pinoccio-firmware/working/mpfr-3.1.2 --with-mpc=/Users/daniel/Projects/Pinoccio/pinoccio-firmware/working/mpc-1.0.1";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
