/* Generated automatically. */
static const char configuration_arguments[] = "../configure --disable-shared --enable-static --prefix=/Applications/Pinoccio.app/Contents/Resources/Java/hardware/tools/avr --target=avr --enable-languages=c,c++ --disable-libssp --disable-nls --with-dwarf2 --with-gmp=/tmp/eric/gmp-5.0.5 --with-mpfr=/tmp/eric/mpfr-3.1.1 --with-mpc=/tmp/eric/mpc-1.0.1";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
